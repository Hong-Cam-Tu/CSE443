using LibraryManagement.data;
using LibraryManagement.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace LibraryManagement.Controllers
{
    public class HomeController : Controller
    {
 
        private readonly LibraryDbContext _context;
        public HomeController(LibraryDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var carouselItems = _context.Carousels
            .Where(c => c.IsActive)
            .OrderBy(c => c.Order)
            .ToList();

            return View(carouselItems);
        }

       public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
    }
}
