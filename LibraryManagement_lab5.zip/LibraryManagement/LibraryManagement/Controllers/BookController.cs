﻿using Microsoft.AspNetCore.Mvc;
using LibraryManagement.Models;
using LibraryManagement.Models.Context;
using Microsoft.EntityFrameworkCore;
using static System.Reflection.Metadata.BlobBuilder;
using System.Net;
namespace LibraryManagement.Controllers
{
    public class BookController : Controller
    {
        private readonly BookContext _Bookcontext;

        public BookController(BookContext context)
        {
            _Bookcontext = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BookDetail(int id)
        {
            var book=_Bookcontext.Books.Where(b=>b.BookId == id);
            ViewBag.Book = book;
            return View(book);
        }
        public IActionResult Category(int categoryId)
        {
            var book = _Bookcontext.Books.Where(b=>b.CategoryId==categoryId). ToList();
            ViewBag.Book = book;
            Console.WriteLine(book);
            return View();
        }

        public IActionResult ReadPDF(int id)
        {
            var book = _Bookcontext.Books.Find(id);
            if (book == null || string.IsNullOrEmpty(book.Pdf))
            {
                return NotFound("PDF not found for this book.");
            }
            ViewBag.PdfUrl = book.Pdf;
            return View();
        }
    }
}
