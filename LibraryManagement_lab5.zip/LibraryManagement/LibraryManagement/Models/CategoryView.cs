﻿namespace LibraryManagement.Models
{
    public class CategoryView
    {
        public string CategoryName { get; set; }
        public List<Books> Books { get; set; }
    }
}
