﻿using LibraryManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagement.data
{
    public class LibraryDbContext: DbContext
    {
        public LibraryDbContext(DbContextOptions<LibraryDbContext> options) : base(options)
        {


        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Carousel>().HasData(
                new Carousel { CarouselId = 1, ImageUrl = "/carousel_images/carousel_1.webp", Title = "Image 1", Description = "Image1", Order = 1, IsActive = true, CreatedDate = DateTime.Now, UpdatedDate = DateTime.Now },
                new Carousel { CarouselId = 2, ImageUrl = "/carousel_images/carousel_2.webp", Title = "Image 2", Description = "Image2", Order = 2, IsActive = true, CreatedDate = DateTime.Now, UpdatedDate = DateTime.Now },
                new Carousel { CarouselId = 3, ImageUrl = "/carousel_images/carousel_3.webp", Title = "Image 3", Description = "Image3", Order = 3, IsActive = true, CreatedDate = DateTime.Now, UpdatedDate = DateTime.Now }
            );
        }



        public DbSet<Book> Books { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Loan> Loans { get; set; }
        public DbSet<Author> Authors { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Carousel> Carousels { get; set; }
    }
}
