﻿using Microsoft.AspNetCore.Mvc;
using LibraryManagement.Models;
namespace LibraryManagement.Controllers
{
    public class BookController : Controller
    {
        public BookController()
        {
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult BookDetail(int id)
        {
            var book = new Book()
            {
/*              Title = "Dế Mèn Phiêu Lưu Ký",
                Author = "Tô Hoài",
                PublishedYear = 1941,
                Category="Tài liệu số sách giáo khoa"
*/            };
            return View(book);
        }
        public async Task<IActionResult> List()
        {
            return View();
        }
    }


}
